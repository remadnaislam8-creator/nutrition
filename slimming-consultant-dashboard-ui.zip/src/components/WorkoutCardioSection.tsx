"use client";

import React, { useState } from "react";
import { Dumbbell, Flame, CheckCircle, Footprints, Clock, Zap, Calendar } from "lucide-react";

export default function WorkoutCardioSection() {
  const [kmWalked, setKmWalked] = useState(8.5);
  const [gymDoneToday, setGymDoneToday] = useState(true);
  const [walkDoneToday, setWalkDoneToday] = useState(false);

  const workoutDays = [
    {
      day: "اليوم 1",
      title: "تمارين الدفع (Push Day)",
      exercises: "بنش بريس فلات (Barbell Bench) + تجميع إنكلاين دنابل + ضغط أكتاف أمامي + ترايسبس بالكيبل",
      sets: "4 مجموعات × 8-12 تكرار",
    },
    {
      day: "اليوم 2",
      title: "تمارين السحب (Pull Day)",
      exercises: "سحب ظهر عريض (Lat Pulldown) + راد طهر بالبار (Barbell Row) + بايسبس هامر + خلفي أكتاف",
      sets: "4 مجموعات × 10-12 تكرار",
    },
    {
      day: "اليوم 3",
      title: "أرجل وبطن (Legs & Abs)",
      exercises: "سكوات باربل (Barbell Squats) + طعن متقدم + ليج كيرل خلفي + طحن بطن ورجل رفع",
      sets: "4 مجموعات × 10-15 تكرار",
    },
    {
      day: "اليوم 4",
      title: "جسم علوي وتنشيف (Upper Body Focus)",
      exercises: "عقلة بوزن الجسم + ضغط سوبر سيت + تجميع جانبي أكتاف + تمارين الساعد والقبضة",
      sets: "3 مجموعات × 12-15 تكرار",
    },
  ];

  const estimatedCaloriesBurned = Math.round(kmWalked * 60);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-6 rounded-2xl shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-semibold mb-1">
              <Dumbbell className="w-5 h-5" />
              <span>النشاط البدني وحرق الدهون العميقة</span>
            </div>
            <h2 className="text-2xl font-bold">🏋️‍♂️ برنامج 4 أيام حديد + 10 كيلومتر مشي</h2>
            <p className="text-slate-300 text-sm mt-1">
              المزيج الخارق للتخلص من الدهون الأحشائية: تمارين المقاومة للبناء والمشي الطويل لنشاط الأيض المستمر.
            </p>
          </div>

          <div className="bg-emerald-900/60 border border-emerald-700/50 p-4 rounded-xl flex items-center gap-3">
            <Footprints className="w-8 h-8 text-teal-400" />
            <div>
              <span className="text-[11px] text-teal-300 block font-semibold">بروتوكول المشي اليومي</span>
              <span className="text-lg font-bold text-white">10 كم = ~600 كالوري</span>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Tracker Widget */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Walking Tracker */}
        <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Footprints className="w-4 h-4 text-teal-600" />
              عداد مشي الـ 10 كيلومتر اليومي
            </h3>
            <span className="text-xs font-bold text-teal-700 bg-teal-100 px-2 py-0.5 rounded-full">
              {kmWalked >= 10 ? "تم تحقيق الهدف! 🎉" : "مستمر..."}
            </span>
          </div>

          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <span>المسافة المقطوعة: {kmWalked} كم</span>
              <span>السعرات المحروقة: ~{estimatedCaloriesBurned} كالوري</span>
            </div>
            <input
              type="range"
              min="0"
              max="15"
              step="0.5"
              value={kmWalked}
              onChange={(e) => setKmWalked(Number(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-slate-500">حوالي {(kmWalked * 1300).toLocaleString()} خطوة</span>
            <button
              onClick={() => setWalkDoneToday(!walkDoneToday)}
              className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1 transition ${
                walkDoneToday ? "bg-teal-600 text-white" : "bg-slate-200 text-slate-700 hover:bg-slate-300"
              }`}
            >
              <CheckCircle className="w-3.5 h-3.5" />
              {walkDoneToday ? "تم إنجاز المشي" : "تحديد كمكتمل"}
            </button>
          </div>
        </div>

        {/* Gym Tracker */}
        <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="flex justify-between items-center">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Dumbbell className="w-4 h-4 text-indigo-600" />
              تمرين المقاومة اليومي
            </h3>
            <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">
              4 أيام أسبوعياً
            </span>
          </div>

          <p className="text-xs text-slate-600">
            تمارين المقاومة تمنع فقدان الألياف العضلية وتجبر الجسم على سحب الطاقة من الخلايا الدهنية المخزنة.
          </p>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-bold text-slate-800">حالة تمرين اليوم:</span>
            <button
              onClick={() => setGymDoneToday(!gymDoneToday)}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                gymDoneToday ? "bg-emerald-600 text-white shadow" : "bg-slate-200 text-slate-700 hover:bg-slate-300"
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              {gymDoneToday ? "أنهيت التمرين اليوم 💪" : "لم أتمرن بعد"}
            </button>
          </div>
        </div>

      </div>

      {/* 4-Day Workout Split Cards */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-bold text-slate-800 text-base flex items-center gap-2 border-b border-slate-100 pb-3">
          <Calendar className="w-4 h-4 text-teal-600" />
          جدول تمارين الحديد 4 أيام
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {workoutDays.map((w, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-50 border border-slate-200 hover:border-teal-300 transition space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold bg-teal-600 text-white px-2.5 py-0.5 rounded-md">
                  {w.day}
                </span>
                <span className="text-[11px] text-slate-500 font-medium">{w.sets}</span>
              </div>
              <h4 className="font-bold text-slate-900 text-sm">{w.title}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">{w.exercises}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
