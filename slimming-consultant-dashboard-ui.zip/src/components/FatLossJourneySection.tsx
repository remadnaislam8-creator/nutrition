"use client";

import React, { useState } from "react";
import { TrendingDown, Scale, Calendar, Plus, Trash2, Award, Target, Flame, ChevronLeft } from "lucide-react";

interface WeightLog {
  id: number;
  date: string;
  weightKg: number;
  waistCm?: number | null;
  chestCm?: number | null;
  bodyFatPercentage?: number | null;
  notes?: string | null;
}

interface Profile {
  id?: number;
  name?: string;
  age?: number;
  gender?: string;
  heightCm?: number;
  currentWeightKg?: number;
  targetWeightKg?: number;
  dailyCalorieGoal?: number;
}

interface FatLossJourneyProps {
  logs: WeightLog[];
  profile: Profile;
  onAddWeightLog: (data: any) => void;
  onDeleteWeightLog: (id: number) => void;
}

export default function FatLossJourneySection({ logs, profile, onAddWeightLog, onDeleteWeightLog }: FatLossJourneyProps) {
  const [newWeight, setNewWeight] = useState(profile.currentWeightKg ? String(profile.currentWeightKg) : "88");
  const [newWaist, setNewWaist] = useState("92");
  const [newChest, setNewChest] = useState("102");
  const [newFatPct, setNewFatPct] = useState("22");
  const [notes, setNotes] = useState("شفت نتائج ممتاز بالالتزام بالأكل البخاري وقطع الغازيات");

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWeight) return;
    onAddWeightLog({
      weightKg: Number(newWeight),
      waistCm: newWaist ? Number(newWaist) : null,
      chestCm: newChest ? Number(newChest) : null,
      bodyFatPercentage: newFatPct ? Number(newFatPct) : null,
      notes,
    });
  };

  const startWeight = logs.length > 0 ? logs[logs.length - 1].weightKg : (profile.currentWeightKg || 95);
  const currentW = profile.currentWeightKg || (logs.length > 0 ? logs[0].weightKg : 90);
  const targetW = profile.targetWeightKg || 70;

  const totalLost = Math.max(0, startWeight - currentW);
  const remaining = Math.max(0, currentW - targetW);
  const totalJourney = Math.max(1, startWeight - targetW);
  const progressPct = Math.min(100, Math.round((totalLost / totalJourney) * 100));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-900 text-white p-6 rounded-2xl shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-teal-400 font-semibold mb-1">
              <TrendingDown className="w-5 h-5" />
              <span>متابعة رحلة التحول وتطور القياسات</span>
            </div>
            <h2 className="text-2xl font-bold">📉 رحلة التحول من السمنة إلى الرشاقة</h2>
            <p className="text-slate-300 text-sm mt-1">
              سجل وزنك اليومي، محيط الخصر، ونسبة الدهون لمتابعة ثبات أو نزول الوزن واستجابة الجسم.
            </p>
          </div>

          <div className="bg-teal-950/80 border border-teal-500/40 p-4 rounded-xl flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-400">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[11px] text-teal-300 font-semibold block">إجمالي الدهون والمفقود</span>
              <span className="text-2xl font-black text-white">{totalLost.toFixed(1)} كجم 📉</span>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-medium block">الوزن الأولي</span>
            <span className="text-xl font-bold text-slate-800">{startWeight} كجم</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-bold">
            🏁
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-teal-200 shadow-sm flex items-center justify-between bg-teal-50/20">
          <div>
            <span className="text-xs text-teal-700 font-medium block">الوزن الحالي</span>
            <span className="text-xl font-bold text-teal-700">{currentW} كجم</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 font-bold">
            <Scale className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-indigo-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-indigo-700 font-medium block">الوزن المستهدف</span>
            <span className="text-xl font-bold text-indigo-700">{targetW} كجم</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
            <Target className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs text-amber-700 font-medium block">المتبقي للهدف</span>
            <span className="text-xl font-bold text-amber-700">{remaining.toFixed(1)} كجم</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 font-bold">
            <Flame className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
        <div className="flex justify-between items-center text-xs font-bold text-slate-800">
          <span>إنجاز خطة التحول</span>
          <span className="text-teal-600">{progressPct}% مكتمل</span>
        </div>
        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-teal-500 to-emerald-400 h-full transition-all duration-700"
            style={{ width: `${progressPct}%` }}
          ></div>
        </div>
      </div>

      {/* Grid: Form (5 cols) & History Table (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Form (5 cols) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 text-base flex items-center gap-2 border-b border-slate-100 pb-3">
            <Plus className="w-4 h-4 text-teal-600" />
            تسجيل قياس جديد اليوم
          </h3>

          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الوزن الحالي (كجم) *</label>
              <input
                type="number"
                step="0.1"
                required
                value={newWeight}
                onChange={(e) => setNewWeight(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-teal-500 bg-slate-50"
                placeholder="مثال: 88.5"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">محيط الخصر (سم)</label>
                <input
                  type="number"
                  step="0.5"
                  value={newWaist}
                  onChange={(e) => setNewWaist(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
                  placeholder="مثال: 90"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">محيط الصدر (سم)</label>
                <input
                  type="number"
                  step="0.5"
                  value={newChest}
                  onChange={(e) => setNewChest(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
                  placeholder="مثال: 104"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">نسبة الدهون المقدرة (%)</label>
              <input
                type="number"
                step="0.1"
                value={newFatPct}
                onChange={(e) => setNewFatPct(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
                placeholder="مثال: 21.5"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ملاحظات المستشار / شعورك</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
                placeholder="مثال: انخفاض ملحوظ في الدهون الأحشائية وزيادة النشاط..."
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition shadow"
            >
              📌 تسجيل وتحديث ملف التحول
            </button>
          </form>
        </div>

        {/* History Table (7 cols) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <h3 className="font-bold text-slate-800 text-base flex items-center gap-2 border-b border-slate-100 pb-3">
            <Calendar className="w-4 h-4 text-teal-600" />
            سجل التطورات والوزن السابق ({logs.length})
          </h3>

          {logs.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-6 text-center">لا توجد قراءات مسجلة بعد. سجل قراءتك الأولى!</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200">
                    <th className="p-2.5">التاريخ</th>
                    <th className="p-2.5">الوزن</th>
                    <th className="p-2.5">الخصر</th>
                    <th className="p-2.5">الدهون</th>
                    <th className="p-2.5">ملاحظات</th>
                    <th className="p-2.5">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="p-2.5 text-slate-600 font-mono text-[11px]">{log.date}</td>
                      <td className="p-2.5 font-bold text-teal-700">{log.weightKg} كجم</td>
                      <td className="p-2.5 text-slate-700">{log.waistCm ? `${log.waistCm} سم` : "-"}</td>
                      <td className="p-2.5 text-slate-700">{log.bodyFatPercentage ? `${log.bodyFatPercentage}%` : "-"}</td>
                      <td className="p-2.5 text-slate-500 max-w-32 truncate">{log.notes || "-"}</td>
                      <td className="p-2.5">
                        <button
                          onClick={() => onDeleteWeightLog(log.id)}
                          className="text-slate-400 hover:text-red-500 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
