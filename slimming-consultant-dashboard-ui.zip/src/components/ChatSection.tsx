"use client";

import React, { useState, useEffect, useRef } from "react";
import { Send, Bot, User, Volume2, VolumeX, Plus, Sparkles, Loader2, Trash2 } from "lucide-react";

interface Message {
  id: number;
  chatId: number;
  role: string;
  content: string;
  createdAt: string;
}

interface Chat {
  id: number;
  title: string;
}

interface ChatSectionProps {
  currentChatId: number;
  messages: Message[];
  chats: Chat[];
  onSendMessage: (msg: string) => Promise<void>;
  onNewChat: () => void;
  onDeleteChat: (id: number) => void;
  loading: boolean;
}

export default function ChatSection({
  currentChatId,
  messages,
  chats,
  onSendMessage,
  onNewChat,
  onDeleteChat,
  loading,
}: ChatSectionProps) {
  const [input, setInput] = useState("");
  const [audioEnabled, setAudioEnabled] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const samplePrompts = [
    "🥗 ما هي الوجبة البخارية المثالية للتنشيف؟",
    "🥔 احسب سعرات 200g بطاطس مفورة و 200g سكالوب",
    "🚫 ما تأثير قطع المشروبات الغازية على الكرش؟",
    "💊 ما جدول المكملات الموصى به مع المشي؟",
    "📉 كيف أتعامل مع ثبات الوزن أثناء الدايت؟",
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  // Audio Speech synthesis function
  const speakText = (text: string) => {
    if (!audioEnabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/[*_#🚫🥗💊📉🏋️‍♂️🥔💧]/g, "");
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = "ar-SA";
      utterance.rate = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error("Speech error:", e);
    }
  };

  useEffect(() => {
    if (messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === "assistant" && audioEnabled) {
        speakText(lastMsg.content);
      }
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const txt = input.trim();
    setInput("");
    await onSendMessage(txt);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Chat Header */}
      <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-teal-600/30 border border-teal-500/40 flex items-center justify-center text-teal-400">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <span>المحادثة مع المساعد الذكي / مستشار التنحيف</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </h3>
            <p className="text-[11px] text-teal-300">خبير التغذية والأكل بالبخار وجدول 10 كم</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Audio toggle */}
          <button
            onClick={() => setAudioEnabled(!audioEnabled)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition ${
              audioEnabled ? "bg-teal-600 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"
            }`}
            title={audioEnabled ? "تعطيل القراءة الصوتية" : "تفعيل القراءة الصوتية باللغة العربية"}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4 text-white" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{audioEnabled ? "الصوت مفعل" : "صوت"}</span>
          </button>

          {/* New Chat Session button */}
          <button
            onClick={onNewChat}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded-xl text-xs font-semibold flex items-center gap-1 border border-slate-700 transition"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">جلسة جديدة</span>
          </button>
        </div>
      </div>

      {/* Quick Prompt Chips */}
      <div className="p-2.5 bg-slate-50 border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-xs shrink-0">
        <Sparkles className="w-4 h-4 text-teal-600 shrink-0 mr-1" />
        <span className="text-[11px] font-bold text-slate-500 shrink-0">مقترحات:</span>
        {samplePrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInput(prompt);
            }}
            className="px-3 py-1 bg-white hover:bg-teal-50 hover:text-teal-800 text-slate-700 rounded-full border border-slate-200 text-[11px] whitespace-nowrap transition shadow-xs"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Messages Box */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
            <Bot className="w-12 h-12 text-teal-500 animate-bounce" />
            <p className="font-bold text-slate-700">أهلاً بك يا بطل! اسألني عن أي شيء يخص التنحيف أو التغذية البخارية.</p>
            <p className="text-xs text-slate-500 max-w-sm">
              أنا هنا لتقديم استشارات مخصصة حول وجباتك (البطاطس، السكالوب، السبانخ)، المكملات، وجدول المشي والتمارين.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === "user";
            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[88%] ${isUser ? "mr-auto flex-row-reverse" : "ml-auto"}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                    isUser ? "bg-teal-700 text-white" : "bg-slate-800 text-teal-400 border border-slate-700"
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap shadow-xs ${
                    isUser
                      ? "bg-teal-600 text-white rounded-tr-xs font-medium"
                      : "bg-white text-slate-800 border border-slate-200 rounded-tl-xs"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            );
          })
        )}

        {loading && (
          <div className="flex gap-3 max-w-[80%] ml-auto items-center text-xs text-teal-700 font-semibold bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
            <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
            <span>جاري تحليل استفسارك وصياغة إجابة المستشار...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="اكتب استفسارك هنا للمستشار..."
          className="flex-1 p-3 rounded-full border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 text-xs sm:text-sm bg-slate-50"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || loading}
          className="px-5 py-3 bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white rounded-full font-bold text-xs sm:text-sm transition flex items-center gap-1.5 shadow"
        >
          <span>إرسال</span>
          <Send className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
}
