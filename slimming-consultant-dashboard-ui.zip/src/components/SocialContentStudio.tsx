"use client";

import React, { useState } from "react";
import { Share2, Video, Copy, Check, ExternalLink, Sparkles, MessageCircle } from "lucide-react";

export default function SocialContentStudio() {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const scripts = [
    {
      title: "🎬 سكريبت تيك توك: سر أكل البطاطس بدون زيادة وزن!",
      duration: "45 ثانية",
      platform: "TikTok / Reels",
      content: `[مشهد: إعداد بطاطس مفورة وسكالوب دجاج]
صوت المتحدث: "توقف عن قطع النشويات لتنحيف كرشك! 🚫 
السر ليس في قطع البطاطس، بل في **البخار**! 
البطاطس المفورة مع ألمستشار تعطي شبع مضاعف وسعرات منخفضة مقارنة بالمقالي. 
ارفقها بـ 200g أسكالوب بالبخار + ماشطو، واقطع الغازيات نهائياً!
رابط لوحة المستشار بالبايو لحساب سعراتك مجاناً 🔥"`,
    },
    {
      title: "🎬 سكريبت انستغرام: ماذا يحدث لجسمك عند قطع المشروبات الغازية لـ 14 يوم؟",
      duration: "30 ثانية",
      platform: "Instagram Reels",
      content: `[مشهد: سكب ماء بارد مع نعناع]
صوت المتحدث: "1. اختفاء احتباس السوائل تحت الجلد. 💧
2. انخفاض هرمون الأنسولين والسماح للدهون الأحشائية بحرق السعرات.
3. زوال الانتفاخ ومشاكل القولون!
استبدلها بـ 4 لتر ماء ومشيت 10 كيلومتر، وشوف فرق القياسات بالأسبوع الأول!"`,
    },
    {
      title: "📝 منشور فيسبوك جاهز للنشر: خطة التحول الاحترافية",
      duration: "منشور نصي",
      platform: "Facebook",
      content: `💥 خطة التنشيف الشاملة من مستشار التنحيف:
- 🥗 **التغذية:** وجبات مفورة بالبخار (بطاطس + سكالوب دجاج + ماشطو وسبانخ).
- 🚫 **القاعدة الصارمة:** صفر مشروبات غازية + 4 لتر ماء daily.
- 💊 **المكملات:** واي بروتين + كافيين مائي + أوميغا 3.
- 🏋️‍♂️ **الرياضة:** 4 أيام حديد + 10 كيلومتر مشي في أيام الراحة.

احصل على خطتك الدقيقة عبر لوحة تحكم المستشار! 🎯`,
    },
  ];

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 text-white p-6 rounded-2xl shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-teal-400 font-semibold mb-1">
              <Share2 className="w-5 h-5" />
              <span>منصة صانع المحتوى والسوشيال ميديا</span>
            </div>
            <h2 className="text-2xl font-bold">📱 صانع محتوى التنحيف والتواصل الاجتماعي</h2>
            <p className="text-slate-300 text-sm mt-1">
              سكريبتات جاهزة ونصوص فيروسية لنشر نصائح الأكل البخاري وقصص التحول عبر حساباتك.
            </p>
          </div>

          <div className="flex gap-2">
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noreferrer"
              className="bg-black hover:bg-slate-800 border border-slate-700 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Video className="w-4 h-4 text-teal-400" /> تيك توك
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:opacity-90 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              انستغرام
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noreferrer"
              className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              فيسبوك
            </a>
          </div>
        </div>
      </div>

      {/* Script cards */}
      <div className="space-y-4">
        {scripts.map((script, idx) => (
          <div key={idx} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-600" />
                <h3 className="font-bold text-slate-800 text-sm">{script.title}</h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-semibold">
                  {script.platform} ({script.duration})
                </span>
                <button
                  onClick={() => handleCopy(script.content, idx)}
                  className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-700 rounded-lg text-xs font-bold flex items-center gap-1 transition border border-teal-200"
                >
                  {copiedIndex === idx ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" /> تم النسخ!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> نسخ النص
                    </>
                  )}
                </button>
              </div>
            </div>

            <pre className="whitespace-pre-wrap font-sans text-xs text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-100 leading-relaxed">
              {script.content}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
}
