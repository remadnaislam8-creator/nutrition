"use client";

import React, { useState } from "react";
import { Salad, Flame, Plus, Trash2, CheckCircle2, AlertTriangle, Scale, Utensils, Droplets } from "lucide-react";

interface DietLog {
  id: number;
  date: string;
  mealName: string;
  foodsJson: Array<{ name: string; grams: number; calories: number; protein: number; carbs: number; fat: number }>;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  notes?: string;
}

interface SteamDietSectionProps {
  logs: DietLog[];
  onAddMeal: (meal: any) => void;
  onDeleteMeal: (id: number) => void;
}

export default function SteamDietSection({ logs, onAddMeal, onDeleteMeal }: SteamDietSectionProps) {
  // Steam food ingredients catalog (per 100g)
  const steamCatalog = [
    { name: "بطاطس مفورة بالبخار", calories: 87, protein: 2.0, carbs: 20.0, fat: 0.1, category: "كربوهيدرات معقدة", icon: "🥔" },
    { name: "أسكالوب دجاج بالبخار", calories: 125, protein: 26.0, carbs: 0.0, fat: 1.8, category: "بروتين صافي", icon: "🍗" },
    { name: "ماشطو (فاصوليا خضراء) بالبخار", calories: 31, protein: 1.8, carbs: 7.0, fat: 0.2, category: "ألياف عالية", icon: "🫛" },
    { name: "سبانخ طازجة بالبخار", calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4, category: "حديد وفيتامينات", icon: "🥬" },
    { name: "سمك فيليه أبيض بالبخار", calories: 95, protein: 20.0, carbs: 0.0, fat: 1.2, category: "أوميغا وبروتين", icon: "🐟" },
    { name: "كوسا وجزر مفور", calories: 28, protein: 1.0, carbs: 6.0, fat: 0.2, category: "حجم وشبع", icon: "🥕" },
  ];

  const [mealName, setMealName] = useState("وجبة التنشيف البخارية");
  const [selectedFoods, setSelectedFoods] = useState<Array<{ name: string; grams: number; calories: number; protein: number; carbs: number; fat: number }>>([
    { name: "بطاطس مفورة بالبخار", grams: 200, calories: 174, protein: 4.0, carbs: 40.0, fat: 0.2 },
    { name: "أسكالوب دجاج بالبخار", grams: 180, calories: 225, protein: 46.8, carbs: 0.0, fat: 3.2 },
    { name: "ماشطو (فاصوليا خضراء) بالبخار", grams: 150, calories: 46, protein: 2.7, carbs: 10.5, fat: 0.3 },
  ]);

  const [selectedFoodIndex, setSelectedFoodIndex] = useState(0);
  const [customGrams, setCustomGrams] = useState(150);

  const addFoodToMeal = () => {
    const foodItem = steamCatalog[selectedFoodIndex];
    const factor = customGrams / 100;
    const newItem = {
      name: foodItem.name,
      grams: customGrams,
      calories: Math.round(foodItem.calories * factor),
      protein: Math.round(foodItem.protein * factor * 10) / 10,
      carbs: Math.round(foodItem.carbs * factor * 10) / 10,
      fat: Math.round(foodItem.fat * factor * 10) / 10,
    };

    setSelectedFoods([...selectedFoods, newItem]);
  };

  const removeFoodFromMeal = (index: number) => {
    setSelectedFoods(selectedFoods.filter((_, i) => i !== index));
  };

  const currentTotals = selectedFoods.reduce(
    (acc, item) => ({
      calories: acc.calories + item.calories,
      protein: Math.round((acc.protein + item.protein) * 10) / 10,
      carbs: Math.round((acc.carbs + item.carbs) * 10) / 10,
      fat: Math.round((acc.fat + item.fat) * 10) / 10,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const handleSaveMeal = () => {
    if (selectedFoods.length === 0) return;
    onAddMeal({
      mealName: mealName || "وجبة بخارية",
      foods: selectedFoods,
      notes: "إعداد بخاري 100% بدون زيوث أو مشروبات غازية",
    });
    setMealName("وجبة تنشيف جديدة");
    setSelectedFoods([]);
  };

  const loadPreset = (presetType: string) => {
    if (presetType === "lunch") {
      setMealName("غداء بخاري متكامل");
      setSelectedFoods([
        { name: "بطاطس مفورة بالبخار", grams: 250, calories: 217, protein: 5.0, carbs: 50.0, fat: 0.2 },
        { name: "أسكالوب دجاج بالبخار", grams: 220, calories: 275, protein: 57.2, carbs: 0.0, fat: 4.0 },
        { name: "ماشطو (فاصوليا خضراء) بالبخار", grams: 150, calories: 46, protein: 2.7, carbs: 10.5, fat: 0.3 },
      ]);
    } else if (presetType === "dinner") {
      setMealName("عشاء بخاري خفيف وحارق");
      setSelectedFoods([
        { name: "سمك فيليه أبيض بالبخار", grams: 200, calories: 190, protein: 40.0, carbs: 0.0, fat: 2.4 },
        { name: "سبانخ طازجة بالبخار", grams: 150, calories: 34, protein: 4.3, carbs: 5.4, fat: 0.6 },
        { name: "كوسا وجزر مفور", grams: 150, calories: 42, protein: 1.5, carbs: 9.0, fat: 0.3 },
      ]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Strict Rules Header */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 rounded-2xl shadow-md border border-slate-700">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-teal-400 font-semibold mb-1">
              <Salad className="w-5 h-5" />
              <span>لوحة التغذية والمحتوى البخاري</span>
            </div>
            <h2 className="text-2xl font-bold">🥗 نظام الأكل بالبخار (التنشيف النظيف)</h2>
            <p className="text-slate-300 text-sm mt-1">
              أفضل الخيارات الغذائية للتخلص من السمنة دون فقدان الكتلة العضلية أو الإضرار بالعمليات الحيوية.
            </p>
          </div>
          <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-xl flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
            <div className="text-xs">
              <p className="font-bold text-amber-300">القاعدة الصارمة للتنحيف</p>
              <p className="text-amber-100">🚫 قطع المشروبات الغازية نهائياً + 💧 4 لتر ماء يومياً</p>
            </div>
          </div>
        </div>
      </div>

      {/* Preset Quick Buttons */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">نماذج وجبات جاهزة:</span>
        <button
          onClick={() => loadPreset("lunch")}
          className="px-3 py-1.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 hover:bg-teal-100 text-xs font-semibold flex items-center gap-1 transition"
        >
          🥔 غداء أسطوري بالبخار (بطاطس + سكالوب + ماشطو)
        </button>
        <button
          onClick={() => loadPreset("dinner")}
          className="px-3 py-1.5 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-800 hover:bg-indigo-100 text-xs font-semibold flex items-center gap-1 transition"
        >
          🐟 عشاء خفيف بالبخار (سمك + سبانخ + كوسا)
        </button>
      </div>

      {/* Main Grid: Catalog Cards & Meal Builder */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Steam Foods Catalog (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-slate-800 text-base mb-3 flex items-center gap-2">
              <Utensils className="w-4 h-4 text-teal-600" />
              الأغذية البخارية الأساسية (لكل 100 جم)
            </h3>
            <div className="space-y-2.5">
              {steamCatalog.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-100 hover:border-teal-300 transition flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{item.icon}</span>
                    <div>
                      <h4 className="font-bold text-slate-800 text-xs">{item.name}</h4>
                      <p className="text-[11px] text-teal-600 font-medium">{item.category}</p>
                    </div>
                  </div>
                  <div className="text-left text-xs">
                    <span className="font-bold text-slate-800 block">{item.calories} كالوري</span>
                    <span className="text-[10px] text-slate-500">
                      ب: {item.protein}g | ك: {item.carbs}g | د: {item.fat}g
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Steaming Tips Card */}
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl text-xs space-y-2 text-emerald-900">
            <h4 className="font-bold flex items-center gap-1.5 text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              💡 أسرار الطهي بالبخار للتنشيف
            </h4>
            <ul className="list-disc list-inside space-y-1 text-emerald-800">
              <li>الطهي بالبخار يحافظ على 95% من الفيتامينات والمعادن القابلة للذوبان.</li>
              <li>استخدم البابريكا، الفلفل الأسود، الكمون، والأوريجانو لتنكيه الطعام بدون سعرات.</li>
              <li>البطاطس المفورة توفر كربوهيدرات بطيئة الامتصاص تمنح العضلات الامتلاء دون تخزين دهون.</li>
            </ul>
          </div>
        </div>

        {/* Steamed Meal Builder & Log (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
                <Scale className="w-4 h-4 text-teal-600" />
                حاسبة وصانع الوجبات البخارية
              </h3>
              <span className="text-xs bg-teal-100 text-teal-800 px-2.5 py-1 rounded-full font-bold">
                مخصص لتنشيف الدهون
              </span>
            </div>

            {/* Meal Title input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">اسم الوجبة</label>
              <input
                type="text"
                value={mealName}
                onChange={(e) => setMealName(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-slate-50"
                placeholder="مثال: غداء البطاطس والسكالوب بالبخار"
              />
            </div>

            {/* Add ingredient controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold text-slate-600 mb-1">اختر الصنف</label>
                <select
                  value={selectedFoodIndex}
                  onChange={(e) => setSelectedFoodIndex(Number(e.target.value))}
                  className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                >
                  {steamCatalog.map((item, idx) => (
                    <option key={idx} value={idx}>
                      {item.icon} {item.name} ({item.calories} كالوري / 100g)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">الكمية (جرام)</label>
                <input
                  type="number"
                  min="10"
                  max="1000"
                  step="10"
                  value={customGrams}
                  onChange={(e) => setCustomGrams(Number(e.target.value))}
                  className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                />
              </div>

              <div className="sm:col-span-3">
                <button
                  onClick={addFoodToMeal}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition"
                >
                  <Plus className="w-3.5 h-3.5" /> إضافة المكون للوجبة
                </button>
              </div>
            </div>

            {/* Selected items list */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-700">مكونات الوجبة الحالية:</h4>
              {selectedFoods.length === 0 ? (
                <p className="text-xs text-slate-400 italic text-center py-4 bg-slate-50 rounded-xl">
                  لم تقم بإضافة أي أطعمة بعد. اختر صنفا وأضفه للوجبة.
                </p>
              ) : (
                <div className="space-y-1.5">
                  {selectedFoods.map((item, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-xl bg-teal-50/50 border border-teal-100 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-800">{item.name}</span>
                        <span className="text-slate-500 mr-2">({item.grams} جرام)</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-teal-700">{item.calories} كالوري</span>
                        <span className="text-[10px] text-slate-500">
                          ب:{item.protein}g | ك:{item.carbs}g | د:{item.fat}g
                        </span>
                        <button
                          onClick={() => removeFoodFromMeal(i)}
                          className="text-red-500 hover:text-red-700 p-1 rounded"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Meal summary totals & save button */}
            <div className="bg-slate-900 text-white p-4 rounded-xl space-y-3">
              <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2">
                <span className="text-slate-400 font-semibold">مجموع القيمة الغذائية للوجبة</span>
                <span className="text-amber-400 font-bold text-base">{currentTotals.calories} كالوري</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">بروتين</span>
                  <span className="font-bold text-emerald-400">{currentTotals.protein} جرام</span>
                </div>
                <div className="bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">كربوهيدرات</span>
                  <span className="font-bold text-amber-400">{currentTotals.carbs} جرام</span>
                </div>
                <div className="bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-400 block text-[10px]">دهون</span>
                  <span className="font-bold text-rose-400">{currentTotals.fat} جرام</span>
                </div>
              </div>
              <button
                onClick={handleSaveMeal}
                disabled={selectedFoods.length === 0}
                className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition shadow"
              >
                💾 حفظ الوجبة في سجل اليوم
              </button>
            </div>
          </div>

          {/* Past Diet Logs */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              سجل الوجبات المسجلة ({logs.length})
            </h3>
            {logs.length === 0 ? (
              <p className="text-xs text-slate-400 italic py-3 text-center">لا توجد وجبات مسجلة اليوم.</p>
            ) : (
              <div className="space-y-2.5 max-h-72 overflow-y-auto pl-1">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-start justify-between gap-2"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800 text-sm">{log.mealName}</span>
                        <span className="text-[10px] text-slate-400">({log.date})</span>
                      </div>
                      <div className="text-[11px] text-slate-600">
                        {log.foodsJson && Array.isArray(log.foodsJson)
                          ? log.foodsJson.map((f: any) => `${f.name} (${f.grams}g)`).join(" + ")
                          : ""}
                      </div>
                      <div className="flex gap-2 text-[10px] text-slate-500 font-medium">
                        <span className="text-teal-700 font-bold">{log.totalCalories} كالوري</span>
                        <span>|</span>
                        <span>بروتين: {log.totalProtein}g</span>
                        <span>|</span>
                        <span>كاربس: {log.totalCarbs}g</span>
                        <span>|</span>
                        <span>دهون: {log.totalFat}g</span>
                      </div>
                    </div>
                    <button
                      onClick={() => onDeleteMeal(log.id)}
                      className="text-slate-400 hover:text-red-500 p-1.5 transition"
                      title="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
