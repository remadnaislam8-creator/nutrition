"use client";

import React from "react";
import {
  MessageSquare,
  Salad,
  Pill,
  TrendingDown,
  Dumbbell,
  Share2,
  Settings,
  Flame,
  Droplet,
  ExternalLink,
  Bot
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  profile: {
    name?: string;
    currentWeightKg?: number;
    targetWeightKg?: number;
    dailyCalorieGoal?: number;
    dailyWaterLiters?: number;
  };
}

export default function Sidebar({ activeTab, setActiveTab, profile }: SidebarProps) {
  const menuItems = [
    { id: "chat", label: "💬 المحادثة مع المساعد الذكي", icon: MessageSquare, badge: "AI Live" },
    { id: "diet", label: "🥗 نظام الأكل بالبخار", icon: Salad, badge: "الوجبات" },
    { id: "supplements", label: "💊 مكملات التنشيف", icon: Pill, badge: "التغذية" },
    { id: "fatloss", label: "📉 رحلة التحول من السمنة", icon: TrendingDown, badge: "السجل" },
    { id: "workout", label: "🏋️‍♂️ تمارين و 10كم مشي", icon: Dumbbell, badge: "الكارديو" },
    { id: "social", label: "📱 صانع محتوى السوشيال", icon: Share2, badge: "تيك توك" },
    { id: "settings", label: "⚙️ إعدادات وحاسبة السعرات", icon: Settings, badge: "الملف" },
  ];

  const lostWeight = (profile.currentWeightKg && profile.targetWeightKg) 
    ? Math.max(0, profile.currentWeightKg - profile.targetWeightKg)
    : 0;

  return (
    <aside className="w-72 bg-slate-900 text-slate-100 flex flex-col border-l border-slate-800 shadow-xl shrink-0 transition-all duration-300">
      {/* Header */}
      <div className="p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-600/20 border border-teal-500/30 flex items-center justify-center text-teal-400 font-bold shadow-inner">
            <Flame className="w-5 h-5 text-teal-400 animate-pulse" />
          </div>
          <div>
            <h1 className="font-bold text-base text-white tracking-wide">منصة مستشار التنحيف</h1>
            <p className="text-xs text-teal-400 font-medium">لوحة التحكم الاحترافية</p>
          </div>
        </div>
      </div>

      {/* User Progress Mini Badge */}
      <div className="mx-4 my-3 p-3 rounded-xl bg-slate-800/80 border border-slate-700/60 flex flex-col gap-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-slate-300 font-semibold">{profile.name || "البطل المتحدي"}</span>
          <span className="px-2 py-0.5 rounded-full text-[11px] bg-teal-500/20 text-teal-300 border border-teal-500/30">
            مرحلة التنشيف
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-center text-xs pt-1 border-t border-slate-700/50">
          <div className="bg-slate-900/60 p-1.5 rounded-lg">
            <span className="text-slate-400 block text-[10px]">الوزن الحالي</span>
            <span className="font-bold text-teal-400 text-sm">{profile.currentWeightKg || 90} كجم</span>
          </div>
          <div className="bg-slate-900/60 p-1.5 rounded-lg">
            <span className="text-slate-400 block text-[10px]">الهدف</span>
            <span className="font-bold text-emerald-400 text-sm">{profile.targetWeightKg || 70} كجم</span>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="px-3 py-2 flex flex-col gap-1.5 overflow-y-auto flex-1">
        <div className="text-[11px] font-bold text-slate-400 px-3 uppercase tracking-wider mb-1">
          القائمة الرئيسية
        </div>
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full text-right py-2.5 px-3.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all duration-200 group ${
                isActive
                  ? "bg-teal-600 text-white font-bold shadow-lg shadow-teal-900/40 translate-x-1"
                  : "text-slate-300 hover:bg-slate-800 hover:text-white"
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? "text-white" : "text-slate-400 group-hover:text-teal-400"}`} />
                <span>{item.label}</span>
              </div>
              <span
                className={`text-[10px] px-2 py-0.5 rounded-md ${
                  isActive
                    ? "bg-teal-700 text-teal-100"
                    : "bg-slate-800 text-slate-400 group-hover:bg-slate-700 group-hover:text-slate-200"
                }`}
              >
                {item.badge}
              </span>
            </button>
          );
        })}
      </div>

      {/* Social Media Section */}
      <div className="p-4 border-t border-slate-800 bg-slate-950 mt-auto">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-400">مواقع التواصل الاجتماعي</span>
          <span className="text-[10px] text-teal-400 flex items-center gap-1">
            متابعة <ExternalLink className="w-2.5 h-2.5" />
          </span>
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          <a
            href="https://tiktok.com"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-slate-800 hover:bg-teal-600 text-slate-200 hover:text-white text-center py-1.5 rounded-lg text-[11px] font-medium transition-colors duration-200 border border-slate-700/50 flex items-center justify-center gap-1"
          >
            تيك توك
          </a>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-slate-800 hover:bg-teal-600 text-slate-200 hover:text-white text-center py-1.5 rounded-lg text-[11px] font-medium transition-colors duration-200 border border-slate-700/50 flex items-center justify-center gap-1"
          >
            انستغرام
          </a>
          <a
            href="https://facebook.com"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-slate-800 hover:bg-teal-600 text-slate-200 hover:text-white text-center py-1.5 rounded-lg text-[11px] font-medium transition-colors duration-200 border border-slate-700/50 flex items-center justify-center gap-1"
          >
            فيسبوك
          </a>
        </div>
      </div>
    </aside>
  );
}
