"use client";

import React, { useState } from "react";
import { Settings, User, Scale, Flame, Droplet, Save, Check } from "lucide-react";

interface Profile {
  id?: number;
  name?: string;
  age?: number;
  gender?: string;
  heightCm?: number;
  currentWeightKg?: number;
  targetWeightKg?: number;
  activityLevel?: string;
  dailyCalorieGoal?: number;
  dailyWaterLiters?: number;
}

interface SettingsSectionProps {
  profile: Profile;
  onUpdateProfile: (updated: any) => void;
}

export default function SettingsSection({ profile, onUpdateProfile }: SettingsSectionProps) {
  const [formData, setFormData] = useState({
    name: profile.name || "البطل المتحدي",
    age: profile.age || 28,
    gender: profile.gender || "male",
    heightCm: profile.heightCm || 175,
    currentWeightKg: profile.currentWeightKg || 90,
    targetWeightKg: profile.targetWeightKg || 70,
    activityLevel: profile.activityLevel || "moderate",
    dailyCalorieGoal: profile.dailyCalorieGoal || 1700,
    dailyWaterLiters: profile.dailyWaterLiters || 3.5,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Auto BMR & Deficit Calculator
  const calculateMacros = () => {
    const w = Number(formData.currentWeightKg) || 90;
    const h = Number(formData.heightCm) || 175;
    const a = Number(formData.age) || 28;

    // BMR Mifflin-St Jeor
    let bmr = 10 * w + 6.25 * h - 5 * a + (formData.gender === "female" ? -161 : 5);
    let tdee = bmr * 1.375; // Moderate active (gym 4 days + walking)
    let fatLossTarget = Math.round(tdee - 500); // 500 kcal deficit

    setFormData((prev) => ({
      ...prev,
      dailyCalorieGoal: fatLossTarget,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 text-white p-6 rounded-2xl shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-teal-400 font-semibold mb-1">
              <Settings className="w-5 h-5" />
              <span>إعدادات ملف المستشار وتعديل الهدف</span>
            </div>
            <h2 className="text-2xl font-bold">⚙️ حاسبة السعرات والبيانات الشخصية</h2>
            <p className="text-slate-300 text-sm mt-1">
              قم بتحديث مقاساتك واحتياجك من السعرات الحرارية والماء لضبط حسابات المساعد الذكي.
            </p>
          </div>
        </div>
      </div>

      {/* Form Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">اسم البطل / العميل</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">العمر</label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الجنس</label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
              >
                <option value="male">ذكر</option>
                <option value="female">أنثى</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الطول (سم)</label>
              <input
                type="number"
                value={formData.heightCm}
                onChange={(e) => setFormData({ ...formData, heightCm: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الوزن الحالي (كجم)</label>
              <input
                type="number"
                step="0.5"
                value={formData.currentWeightKg}
                onChange={(e) => setFormData({ ...formData, currentWeightKg: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-bold text-teal-700"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">الوزن المستهدف (كجم)</label>
              <input
                type="number"
                step="0.5"
                value={formData.targetWeightKg}
                onChange={(e) => setFormData({ ...formData, targetWeightKg: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-bold text-emerald-700"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">مستوى النشاط اليومي</label>
              <select
                value={formData.activityLevel}
                onChange={(e) => setFormData({ ...formData, activityLevel: e.target.value })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50"
              >
                <option value="sedentary">قليل النشاط</option>
                <option value="moderate">متوسط (4 أيام جيم + مشي)</option>
                <option value="active">عالي (رياضي وملتزم بـ 10 كم)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">هدف السعرات اليومي (كالوري)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={formData.dailyCalorieGoal}
                  onChange={(e) => setFormData({ ...formData, dailyCalorieGoal: Number(e.target.value) })}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-bold text-amber-700"
                />
                <button
                  type="button"
                  onClick={calculateMacros}
                  className="px-2.5 py-1 bg-amber-100 text-amber-800 rounded-xl text-[11px] font-bold shrink-0 hover:bg-amber-200 transition"
                  title="احتساب تلقائي بناءً على معطياتك"
                >
                  حساب تلقائي ⚡
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">هدف شرب الماء اليومي (لتر)</label>
              <input
                type="number"
                step="0.5"
                value={formData.dailyWaterLiters}
                onChange={(e) => setFormData({ ...formData, dailyWaterLiters: Number(e.target.value) })}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 bg-slate-50 font-bold text-blue-700"
              />
            </div>

          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            {savedSuccess && (
              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <Check className="w-4 h-4" /> تم حفظ التعديلات بنجاح!
              </span>
            )}
            <button
              type="submit"
              className="mr-auto px-6 py-2.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" /> حفظ البيانات والهدف
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
