"use client";

import React, { useState, useEffect } from "react";
import { Pill, CheckSquare, Square, Clock, ShieldCheck, Zap, Heart, Flame, Sparkles } from "lucide-react";

interface SupplementsSectionProps {
  dateStr: string;
}

interface SupplementItem {
  id: string;
  name: string;
  category: string;
  dosage: string;
  timeOfDay: string;
  description: string;
  taken: boolean;
  icon: any;
  color: string;
}

export default function SupplementsSection({ dateStr }: SupplementsSectionProps) {
  const [supplements, setSupplements] = useState<SupplementItem[]>([
    {
      id: "whey",
      name: "الواي بروتين (Whey Protein Isolate)",
      category: "حماية العضلات",
      dosage: "1 سكوب (30 جم بروتين)",
      timeOfDay: "بعد التمرين مباشرة أو بين الوجبات",
      description: "يحمي الكتلة العضلية من التفكك العضلي أثناء العجز السعري الشديد ويحفز البناء البروتيني.",
      taken: false,
      icon: Flame,
      color: "border-teal-500/40 bg-teal-500/5 text-teal-600",
    },
    {
      id: "caffeine",
      name: "الكافيين المائي (Anhydrous Caffeine)",
      category: "حارق طاقة وميتابوليزم",
      dosage: "200 ملجم (أو فنجان قهوة سوداء)",
      timeOfDay: "قبل تمارين المقاومة أو مشي 10 كم بـ 30 دقيقة",
      description: "يرفع معدل الأيض Basal Metabolic Rate، يزيد التركيز الذاتي، ويساعد على أكسدة الدهون الأحشائية.",
      taken: false,
      icon: Zap,
      color: "border-amber-500/40 bg-amber-500/5 text-amber-600",
    },
    {
      id: "omega3",
      name: "أوميغا 3 (Omega-3 Fish Oil)",
      category: "صحة المفاصل والأيض",
      dosage: "2000 - 3000 ملجم",
      timeOfDay: "مع وجبة الغداء البخارية الرئيسية",
      description: "يقلل التهابات المفاصل أثناء الأوزان الثقيلة، يحسن حساسية الأنسولين، ويدعم صحة القلب والشرايين.",
      taken: false,
      icon: Heart,
      color: "border-indigo-500/40 bg-indigo-500/5 text-indigo-600",
    },
    {
      id: "carnitine",
      name: "إل-كارنيتين (L-Carnitine L-Tartrate)",
      category: "ناقل الأحماض الدهنية",
      dosage: "2000 ملجم سائل أو أقراص",
      timeOfDay: "قبل الكارديو / مشي الـ 10 كيلومترات",
      description: "ينقل الأحماض الدهنية طويلة السلسلة إلى خلايا الميتوكندريا ليتم حرقها وتحويلها إلى طاقة حركية.",
      taken: false,
      icon: Sparkles,
      color: "border-emerald-500/40 bg-emerald-500/5 text-emerald-600",
    },
    {
      id: "multivitamin",
      name: "فيتامينات متعددة ومعادن (Multivitamin & Minerals)",
      category: "صحة عامة وإلكترولايت",
      dosage: "قرص واحد يومياً",
      timeOfDay: "صباحاً مع الإفطار",
      description: "يعوض نقص المايكرو-نيوترينت الناتج عن تقليل السعرات ويحافظ على سلامة المناعة والبشرة والشعر.",
      taken: false,
      icon: ShieldCheck,
      color: "border-blue-500/40 bg-blue-500/5 text-blue-600",
    },
  ]);

  // Load status from backend
  useEffect(() => {
    async function loadLogs() {
      try {
        const res = await fetch(`/api/supplements?date=${dateStr}`);
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            setSupplements((prev) =>
              prev.map((item) => {
                const found = data.find((d: any) => d.supplementName === item.name);
                return found ? { ...item, taken: found.taken } : item;
              })
            );
          }
        }
      } catch (err) {
        console.error("Error loading supplement status:", err);
      }
    }
    loadLogs();
  }, [dateStr]);

  const toggleTaken = async (id: string) => {
    const updated = supplements.map((s) => (s.id === id ? { ...s, taken: !s.taken } : s));
    setSupplements(updated);

    const target = updated.find((s) => s.id === id);
    if (!target) return;

    try {
      await fetch("/api/supplements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          supplementName: target.name,
          taken: target.taken,
          dosage: target.dosage,
          timeOfDay: target.timeOfDay,
          date: dateStr,
        }),
      });
    } catch (err) {
      console.error("Error saving supplement log:", err);
    }
  };

  const takenCount = supplements.filter((s) => s.taken).length;
  const progressPercent = Math.round((takenCount / supplements.length) * 100);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white p-6 rounded-2xl shadow-md border border-slate-700">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-semibold mb-1">
              <Pill className="w-5 h-5" />
              <span>دليل المكملات الغذائية للتنشيف وحرق الشحوم</span>
            </div>
            <h2 className="text-2xl font-bold">💊 مكملات التنشيف الموصى بها</h2>
            <p className="text-slate-300 text-sm mt-1">
              مكملات مثبتة علمياً للحفاظ على الألياف العضلية وتجهيز الجسم للتمارين القاسية أثناء دايت العجز.
            </p>
          </div>

          <div className="bg-indigo-900/60 border border-indigo-700/50 p-4 rounded-xl flex flex-col items-center min-w-44 text-center">
            <span className="text-xs text-indigo-300 font-semibold mb-1">نسبة التزام اليوم</span>
            <span className="text-2xl font-extrabold text-teal-400">{progressPercent}%</span>
            <div className="w-full bg-slate-700 h-2 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-teal-400 h-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            <span className="text-[10px] text-slate-400 mt-1">
              {takenCount} من {supplements.length} مكملات
            </span>
          </div>
        </div>
      </div>

      {/* Supplement Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {supplements.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition-all duration-200 bg-white shadow-sm flex flex-col justify-between ${
                item.taken ? "border-teal-500 ring-1 ring-teal-500/20 bg-teal-50/20" : "border-slate-200"
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-xl border ${item.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 block">
                        {item.category}
                      </span>
                      <h3 className="font-bold text-slate-900 text-sm">{item.name}</h3>
                    </div>
                  </div>

                  <button
                    onClick={() => toggleTaken(item.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      item.taken
                        ? "bg-teal-600 text-white shadow-sm"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {item.taken ? (
                      <>
                        <CheckSquare className="w-4 h-4 text-white" /> تم تناوله
                      </>
                    ) : (
                      <>
                        <Square className="w-4 h-4 text-slate-400" /> لم يتم بعد
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-600 mt-2 leading-relaxed">{item.description}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-800">الجرعة:</span>
                  <span className="text-slate-600">{item.dosage}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span className="text-slate-700 font-medium">{item.timeOfDay}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Safety & Best Practices Note */}
      <div className="bg-slate-900 text-slate-200 p-5 rounded-2xl border border-slate-800 flex items-start gap-3">
        <ShieldCheck className="w-6 h-6 text-teal-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <h4 className="font-bold text-white text-sm">إرشادات الأمان والمكملات الغذائية</h4>
          <p className="text-slate-300">
            المكملات الغذائية هي عوامل مساعدة وليست بديلاً عن الوجبات البخارية الأساسية (البطاطس، السكالوب، الماشطو).
            تأكد دائماً من شرب كميات وفيرة من المياه (3.5 - 4 لتر) لتسهيل امتصاص البروتين وتجنب ترسبات الكلى.
          </p>
        </div>
      </div>
    </div>
  );
}
