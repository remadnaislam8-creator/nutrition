import { pgTable, serial, text, integer, real, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("البطل"),
  age: integer("age").notNull().default(28),
  gender: text("gender").notNull().default("male"), // male, female
  heightCm: real("height_cm").notNull().default(175),
  currentWeightKg: real("current_weight_kg").notNull().default(95),
  targetWeightKg: real("target_weight_kg").notNull().default(75),
  activityLevel: text("activity_level").notNull().default("moderate"), // sedentary, moderate, active
  dailyCalorieGoal: integer("daily_calorie_goal").notNull().default(1800),
  dailyWaterLiters: real("daily_water_liters").notNull().default(3.5),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("محادثة جديدة"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: integer("chat_id").references(() => chats.id, { onDelete: "cascade" }).notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dietLogs = pgTable("diet_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  mealName: text("meal_name").notNull(), // e.g., 'وجبة الغداء البخارية'
  foodsJson: jsonb("foods_json").notNull(), // list of foods selected
  totalCalories: integer("total_calories").notNull().default(0),
  totalProtein: real("total_protein").notNull().default(0),
  totalCarbs: real("total_carbs").notNull().default(0),
  totalFat: real("total_fat").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const weightLogs = pgTable("weight_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  weightKg: real("weight_kg").notNull(),
  waistCm: real("waist_cm"),
  chestCm: real("chest_cm"),
  bodyFatPercentage: real("body_fat_percentage"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const supplementLogs = pgTable("supplement_logs", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD
  supplementName: text("supplement_name").notNull(),
  taken: boolean("taken").notNull().default(false),
  dosage: text("dosage"),
  timeOfDay: text("time_of_day"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
