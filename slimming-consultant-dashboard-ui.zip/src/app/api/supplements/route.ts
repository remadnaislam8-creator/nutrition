import { NextResponse } from "next/server";
import { db } from "@/db";
import { supplementLogs } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const date = searchParams.get("date") || new Date().toISOString().split("T")[0];

    const logs = await db.select().from(supplementLogs).where(eq(supplementLogs.date, date));
    return NextResponse.json(logs);
  } catch (error) {
    console.error("Error fetching supplement logs:", error);
    return NextResponse.json({ error: "فشل جلب سجل المكملات" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { supplementName, taken, dosage, timeOfDay, date } = body;

    const todayStr = date || new Date().toISOString().split("T")[0];

    const existing = await db
      .select()
      .from(supplementLogs)
      .where(and(eq(supplementLogs.date, todayStr), eq(supplementLogs.supplementName, supplementName)))
      .limit(1);

    if (existing.length > 0) {
      const [updated] = await db
        .update(supplementLogs)
        .set({ taken: Boolean(taken), dosage, timeOfDay })
        .where(eq(supplementLogs.id, existing[0].id))
        .returning();
      return NextResponse.json(updated);
    } else {
      const [newLog] = await db.insert(supplementLogs).values({
        date: todayStr,
        supplementName,
        taken: Boolean(taken),
        dosage: dosage || "",
        timeOfDay: timeOfDay || "صباحاً",
      }).returning();
      return NextResponse.json(newLog);
    }
  } catch (error) {
    console.error("Error toggling supplement:", error);
    return NextResponse.json({ error: "فشل تحديث سجل المكمل" }, { status: 500 });
  }
}
