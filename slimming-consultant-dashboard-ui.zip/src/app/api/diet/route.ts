import { NextResponse } from "next/server";
import { db } from "@/db";
import { dietLogs } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const logs = await db.select().from(dietLogs).orderBy(desc(dietLogs.createdAt)).limit(30);
    return NextResponse.json(logs);
  } catch (error) {
    console.error("Error fetching diet logs:", error);
    return NextResponse.json({ error: "فشل جلب سجلات التغذية" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { mealName, foods, notes, date } = body;

    if (!mealName || !foods || !Array.isArray(foods)) {
      return NextResponse.json({ error: "بيانات الوجبة غير مكتملة" }, { status: 400 });
    }

    // Calculate totals
    let totalCalories = 0;
    let totalProtein = 0;
    let totalCarbs = 0;
    let totalFat = 0;

    for (const food of foods) {
      totalCalories += Number(food.calories || 0);
      totalProtein += Number(food.protein || 0);
      totalCarbs += Number(food.carbs || 0);
      totalFat += Number(food.fat || 0);
    }

    const todayStr = date || new Date().toISOString().split("T")[0];

    const [newLog] = await db.insert(dietLogs).values({
      date: todayStr,
      mealName: mealName || "وجبة بخارية",
      foodsJson: foods,
      totalCalories: Math.round(totalCalories),
      totalProtein: Math.round(totalProtein * 10) / 10,
      totalCarbs: Math.round(totalCarbs * 10) / 10,
      totalFat: Math.round(totalFat * 10) / 10,
      notes: notes || "",
    }).returning();

    return NextResponse.json(newLog);
  } catch (error) {
    console.error("Error adding diet log:", error);
    return NextResponse.json({ error: "فشل حفظ الوجبة" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "المعرف مطلوب" }, { status: 400 });

    await db.delete(dietLogs).where(eq(dietLogs.id, parseInt(id, 10)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting diet log:", error);
    return NextResponse.json({ error: "فشل حذف الوجبة" }, { status: 500 });
  }
}
