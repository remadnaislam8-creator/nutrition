import { NextResponse } from "next/server";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const existing = await db.select().from(profiles).limit(1);
    if (existing.length === 0) {
      // Create default profile
      const [newProfile] = await db.insert(profiles).values({
        name: "البطل المتحدي",
        age: 28,
        gender: "male",
        heightCm: 175,
        currentWeightKg: 92,
        targetWeightKg: 72,
        activityLevel: "moderate",
        dailyCalorieGoal: 1750,
        dailyWaterLiters: 3.5,
      }).returning();
      return NextResponse.json(newProfile);
    }
    return NextResponse.json(existing[0]);
  } catch (error) {
    console.error("Error fetching profile:", error);
    return NextResponse.json({ error: "فشل جلب ملف المستشار" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const existing = await db.select().from(profiles).limit(1);

    if (existing.length === 0) {
      const [newProfile] = await db.insert(profiles).values({
        name: body.name || "البطل المتحدي",
        age: Number(body.age) || 28,
        gender: body.gender || "male",
        heightCm: Number(body.heightCm) || 175,
        currentWeightKg: Number(body.currentWeightKg) || 90,
        targetWeightKg: Number(body.targetWeightKg) || 70,
        activityLevel: body.activityLevel || "moderate",
        dailyCalorieGoal: Number(body.dailyCalorieGoal) || 1700,
        dailyWaterLiters: Number(body.dailyWaterLiters) || 3.5,
      }).returning();
      return NextResponse.json(newProfile);
    } else {
      const [updated] = await db.update(profiles)
        .set({
          name: body.name ?? existing[0].name,
          age: body.age !== undefined ? Number(body.age) : existing[0].age,
          gender: body.gender ?? existing[0].gender,
          heightCm: body.heightCm !== undefined ? Number(body.heightCm) : existing[0].heightCm,
          currentWeightKg: body.currentWeightKg !== undefined ? Number(body.currentWeightKg) : existing[0].currentWeightKg,
          targetWeightKg: body.targetWeightKg !== undefined ? Number(body.targetWeightKg) : existing[0].targetWeightKg,
          activityLevel: body.activityLevel ?? existing[0].activityLevel,
          dailyCalorieGoal: body.dailyCalorieGoal !== undefined ? Number(body.dailyCalorieGoal) : existing[0].dailyCalorieGoal,
          dailyWaterLiters: body.dailyWaterLiters !== undefined ? Number(body.dailyWaterLiters) : existing[0].dailyWaterLiters,
          updatedAt: new Date(),
        })
        .where(eq(profiles.id, existing[0].id))
        .returning();
      return NextResponse.json(updated);
    }
  } catch (error) {
    console.error("Error updating profile:", error);
    return NextResponse.json({ error: "فشل تحديث البيانات" }, { status: 500 });
  }
}
