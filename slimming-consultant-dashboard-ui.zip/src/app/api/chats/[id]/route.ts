import { NextResponse } from "next/server";
import { db } from "@/db";
import { chats, messages } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const chatId = parseInt(id, 10);
    if (isNaN(chatId)) {
      return NextResponse.json({ error: "معرف غير صالح" }, { status: 400 });
    }

    const chatMessages = await db
      .select()
      .from(messages)
      .where(eq(messages.chatId, chatId))
      .orderBy(asc(messages.createdAt));

    return NextResponse.json(chatMessages);
  } catch (error) {
    console.error("Error fetching chat messages:", error);
    return NextResponse.json({ error: "فشل جلب الرسائل" }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const chatId = parseInt(id, 10);
    if (isNaN(chatId)) {
      return NextResponse.json({ error: "معرف غير صالح" }, { status: 400 });
    }

    await db.delete(chats).where(eq(chats.id, chatId));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting chat:", error);
    return NextResponse.json({ error: "فشل حذف المحادثة" }, { status: 500 });
  }
}
