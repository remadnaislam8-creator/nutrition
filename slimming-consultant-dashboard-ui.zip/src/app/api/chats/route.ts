import { NextResponse } from "next/server";
import { db } from "@/db";
import { chats, messages } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const chatList = await db.select().from(chats).orderBy(desc(chats.createdAt));
    if (chatList.length === 0) {
      // Create initial main chat
      const [newChat] = await db.insert(chats).values({ title: "مستشار التنشيف والتنحيف" }).returning();
      
      // Insert welcome message
      await db.insert(messages).values({
        chatId: newChat.id,
        role: "assistant",
        content: "أهلاً بك يا بطل في منصة مستشار التنحيف والتنشيف الاحترافية! 🥗🔥\n\nأنا هنا لمساعدتك في خطة التحول: الوجبات البخارية (بطاطس، سكالوب، ماشطو)، المكملات الغذائية، قطع المشروبات الغازية، وبرنامج 10 كم مشي مع المقاومة.\n\nكيف أستطيع مساعدتك اليوم؟",
      });

      return NextResponse.json([{ ...newChat, messageCount: 1 }]);
    }
    return NextResponse.json(chatList);
  } catch (error) {
    console.error("Error fetching chats:", error);
    return NextResponse.json({ error: "فشل جلب المحادثات" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const title = body.title || "محادثة استشارية جديدة";
    
    const [newChat] = await db.insert(chats).values({ title }).returning();
    
    await db.insert(messages).values({
      chatId: newChat.id,
      role: "assistant",
      content: "مرحباً بك في جلسة استشارية جديدة! 🎯 اسألني عن الوجبات البخارية، السعرات الحرارية، المكملات، أو خطتك للتخلص من السمنة.",
    });

    return NextResponse.json(newChat);
  } catch (error) {
    console.error("Error creating chat:", error);
    return NextResponse.json({ error: "فشل إنشاء محادثة" }, { status: 500 });
  }
}
