import { NextResponse } from "next/server";
import { db } from "@/db";
import { weightLogs, profiles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const logs = await db.select().from(weightLogs).orderBy(desc(weightLogs.createdAt)).limit(30);
    return NextResponse.json(logs);
  } catch (error) {
    console.error("Error fetching weight logs:", error);
    return NextResponse.json({ error: "فشل جلب سجل الوزن" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { weightKg, waistCm, chestCm, bodyFatPercentage, notes, date } = body;

    if (!weightKg) {
      return NextResponse.json({ error: "يرجى أدخال قيمة الوزن" }, { status: 400 });
    }

    const todayStr = date || new Date().toISOString().split("T")[0];

    const [newLog] = await db.insert(weightLogs).values({
      date: todayStr,
      weightKg: Number(weightKg),
      waistCm: waistCm ? Number(waistCm) : null,
      chestCm: chestCm ? Number(chestCm) : null,
      bodyFatPercentage: bodyFatPercentage ? Number(bodyFatPercentage) : null,
      notes: notes || "",
    }).returning();

    // Also update current weight in profile
    const existingProfile = await db.select().from(profiles).limit(1);
    if (existingProfile[0]) {
      await db.update(profiles)
        .set({ currentWeightKg: Number(weightKg), updatedAt: new Date() })
        .where(eq(profiles.id, existingProfile[0].id));
    }

    return NextResponse.json(newLog);
  } catch (error) {
    console.error("Error adding weight log:", error);
    return NextResponse.json({ error: "فشل إضافة القراءة" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "المعرف مطلوب" }, { status: 400 });

    await db.delete(weightLogs).where(eq(weightLogs.id, parseInt(id, 10)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting weight log:", error);
    return NextResponse.json({ error: "فشل حذف القراءة" }, { status: 500 });
  }
}
