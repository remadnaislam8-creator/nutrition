import { NextResponse } from "next/server";
import { db } from "@/db";
import { messages, profiles, chats } from "@/db/schema";
import { eq } from "drizzle-orm";

function generateConsultantResponse(prompt: string, profile: { currentWeightKg?: number; targetWeightKg?: number; age?: number; heightCm?: number; dailyCalorieGoal?: number }): string {
  const query = prompt.toLowerCase().trim();

  // 1. Steam diet & meals
  if (query.includes("بخار") || query.includes("مفور") || query.includes("بطاطس") || query.includes("سكالوب") || query.includes("ماشطو") || query.includes("سبانخ") || query.includes("طعام") || query.includes("وجبة") || query.includes("أكل")) {
    return `🥗 **نظام الأكل بالبخار (التغذية النظيفة للتنشيف)**

يا بطل، الوجبات المفورة بالبخار هي المفتاح الأساسي للتخلص من الدهون المحتبسة دون الشعور بالجوع:

1. **البطاطس المفورة (Steamed Potatoes):**
   - 200 جرام يوفر طاقة ممتازة (حوالي 170 حريرة) وكربوهيدرات معقدة تحافظ على امتلاء العضلات بالفليكوجين.
2. **أسكالوب الدجاج بالبخار:**
   - 200 جرام يوفر 42g بروتين صافي لبناء الألياف العضلية وحمايتها أثناء العجز.
3. **الماشطو (الفاصوليا الخضراء) والسبانخ:**
   - خضروات بخارية غنية بالألياف والمعادن وتمنحك شعوراً بالشبع طوال اليوم.
4. **القاعدة الذهبية:**
   - يمنع منعاً باتاً إضافة الزيوت المهدرجة أو المشروبات الغازية! تبل بالملح الخفيف والأعشاب المنكهة (اوريجانو، بابريكا، ثوم).

💡 **تلميحة:** تناول وجبتك الرئيسية بالبخار بعد التمرين بـ 30-45 دقيقة لتعظيم بناء البروتين.`;
  }

  // 2. Soda & Sugar cutoff
  if (query.includes("غاز") || query.includes("بيبسي") || query.includes("كوكا") || query.includes("سكر") || query.includes("عصير") || query.includes("مشروب")) {
    return `🚫 **القطع التام للمشروبات الغازية والسكريات**

أحسنت بفتح هذا الموضوع! المشروبات الغازية والعصائر المصنعة هي السبب رقم 1 في السمنة وتراكم الدهون الأحشائية حول البطن:

• **لماذا نقطع المشروبات الغازية؟**
  1. ترتفع نسبة الأنسولين بسرعة فائقة، مما يوقف عملية حرق الدهون تماماً لمدة تصل إلى 6 ساعات.
  2. تسبب انتفاخ المعدة وتخزين احتباس السوائل تحت الجلد.
  3. المشروبات "الدايت" قد تخدع العقل وتحفز الشهية للسكريات.

💧 **البديل الموصى به:**
- اشرب 3.5 إلى 4 لتر ماء يومياً.
- يمكنك إضافة شريحة ليمون أو أوراق نعناع طازجة.
- الشاي الأخضر والقهوة المفلترة بدون سكر يرفعان معدل الحرق بشكل ممتاز!`;
  }

  // 3. Supplements
  if (query.includes("مكمل") || query.includes("واي") || query.includes("بروتين") || query.includes("كافيين") || query.includes("اوميغا") || query.includes("كارنيتين") || query.includes("حبوب")) {
    return `💊 **استراتيجية مكملات التنشيف الموصى بها**

للحصول على جسم مشدود وأقصى كفاءة لحرق الدهون مع الحفاظ على العضلات:

1. **الواي بروتين (Whey Protein Isolate):**
   - جرعة: 1-2 سكوب يومياً (خاصة بعد التمرين أو بين الوجبات).
   - الفائدة: يمنع التفكك العضلي ويغطي الاحتياج اليومي للبروتين.

2. **الكافيين المائي (Anhydrous Caffeine):**
   - جرعة: 200mg قبل تمارين المقاومة أو مشي الـ 10 كم بـ 30 دقيقة.
   - الفائدة: يعزز التركيز، يرفع معدل الأيض Basal Metabolic Rate ويحفز حرق الأحماض الدهنية.

3. **أوميغا 3 (Omega-3 Fish Oil):**
   - جرعة: 2000mg-3000mg يومياً مع الوجبات.
   - الفائدة: يقلل الالتهابات، يحسن حساسية الأنسولين، ويدعم صحة المفاصل أثناء التنشيف.

4. **إل-كارنيتين (L-Carnitine L-Tartrate):**
   - جرعة: 2g قبل حصة الكارديو.
   - الفائدة: ينقل الأحماض الدهنية إلى الميتوكندريا لإنتاج الطاقة.`;
  }

  // 4. Exercise / Walking 10km / Gym
  if (query.includes("رياضة") || query.includes("تمرين") || query.includes("مشي") || query.includes("10") || query.includes("كارديو") || query.includes("حديد") || query.includes("جيم") || query.includes("خطوة")) {
    return `🏋️‍♂️ **برنامج النشاط البدني: 4 أيام حديد + 10 كيلومتر مشي**

للوصول إلى أعلى معدل لتكسير الشحوم:

• **تمارين المقاومة (4 أيام أسبوعياً):**
  - توزيع المقترحات: Push / Pull / Legs / Upper Body.
  - التركيز على الأوزان المتوسطة إلى الثقيلة لـ 8-12 تكرار للحفاظ على الكتلة العضلية.

• **المشي 10 كيلومترات (في أيام الراحة والنشاط اليومي):**
  - 10 كم تعادل حوالي 12,000 إلى 14,000 خطوة.
  - تحرق ما يقارب 500 - 650 حريرة إضافية دون إجهاد الجهاز العصبي المركزي (CNS).
  - المشي السريع على معدة فارغة صباحاً أو مساءً يعزز حرق الدهون العميقة.`;
  }

  // 5. Weight loss plateau / Motivation
  if (query.includes("ثبات") || query.includes("وزني") || query.includes("توقف") || query.includes("بطء") || query.includes("نزول") || query.includes("خسارة")) {
    const curW = profile.currentWeightKg || 90;
    const tgtW = profile.targetWeightKg || 70;
    const diff = curW - tgtW;

    return `📉 **تحليل رحلة التحول وتجاوز ثبات الوزن**

وزنك الحالي: **${curW} كجم** | الهدف: **${tgtW} كجم** (المتبقي: ${diff} كجم).

**عندما يتوقف الوزن عن النزول، اتبع الخطة التالية:**
1. **احسب سعراتك بدقة:** تأكد من أنك في عجز سعري (1600 - 1800 كالوري) ولا تغفل حساب الزيوت أو الصلصات المخفية.
2. **زيادة عدد الخطوات:** إذا كنت تمشي 7 كم، ارفع المجموع إلى **10 كيلومتر يومياً**.
3. **يوم كسر الثبات (Refeed Day):** تناول وجبة عالية الكربوهيدرات النظيفة (بطاطس مفورة مضاعفة) لإعادة تنشيط هرمون اللبتين وحث الغدة الدرقية.
4. **شرب الماء:** تأكد من تجاوز 3.5 لتر ماء لإخراج الاحتباس المائي.

أنت في الطريق الصحيح يا بطل، لا تستسلم! 💪`;
  }

  // General consultant response
  return `💪 **نصيحة مستشار التنحيف:**

للحصول على أفضل نتيجة في رحلة الرشاقة والتنشيف:
- **التغذية:** ركز على الوجبات البخارية (بطاطس مفورة، سكالوب دجاج، ماشطو وسبانخ).
- **المشروبات:** اقطع المشروبات الغازية نهائياً واشرب 3.5 - 4 لتر ماء يومياً.
- **الحركة:** مارس تمارين المقاومة 4 أيام واحرص على مشي 10 كيلومترات في أيام الراحة.
- **المكملات:** الواي بروتين للحفاظ على العضلات والكافيين لرفع معدل الحرق.

هل تحب أن نحسب لك السعرات الحرارية الدقيقة لوجباتك اليومية؟ أخبرني بوزنك وطولك الآن!`;
}

export async function POST(req: Request) {
  try {
    const { chatId, message } = await req.json();

    if (!chatId || !message) {
      return NextResponse.json({ error: "الرسالة ومعرف المحادثة مطلوبان" }, { status: 400 });
    }

    // Insert User Message
    await db.insert(messages).values({
      chatId,
      role: "user",
      content: message,
    });

    // Get user profile for contextual customized answers
    const userProfile = await db.select().from(profiles).limit(1);
    const prof = userProfile[0] || {};

    // Generate AI Response
    const botAnswer = generateConsultantResponse(message, prof);

    // Save Bot Response
    const [botMsg] = await db.insert(messages).values({
      chatId,
      role: "assistant",
      content: botAnswer,
    }).returning();

    // Auto update chat title if it's default
    const currentChat = await db.select().from(chats).where(eq(chats.id, chatId)).limit(1);
    if (currentChat[0] && currentChat[0].title === "محادثة جديدة") {
      const summaryTitle = message.slice(0, 30) + (message.length > 30 ? "..." : "");
      await db.update(chats).set({ title: summaryTitle }).where(eq(chats.id, chatId));
    }

    return NextResponse.json({ reply: botMsg });
  } catch (error) {
    console.error("Error sending message:", error);
    return NextResponse.json({ error: "حدث خطأ أثناء معالجة الرسالة" }, { status: 500 });
  }
}
