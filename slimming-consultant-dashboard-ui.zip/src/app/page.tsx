"use client";

import React, { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import ChatSection from "@/components/ChatSection";
import SteamDietSection from "@/components/SteamDietSection";
import SupplementsSection from "@/components/SupplementsSection";
import FatLossJourneySection from "@/components/FatLossJourneySection";
import WorkoutCardioSection from "@/components/WorkoutCardioSection";
import SocialContentStudio from "@/components/SocialContentStudio";
import SettingsSection from "@/components/SettingsSection";

import { MessageSquare, Salad, Pill, TrendingDown, Dumbbell, Share2, Settings, Flame, Droplets, Info } from "lucide-react";

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("chat");
  const [profile, setProfile] = useState<any>({
    name: "البطل المتحدي",
    currentWeightKg: 92,
    targetWeightKg: 72,
    dailyCalorieGoal: 1750,
    dailyWaterLiters: 3.5,
  });

  const [chats, setChats] = useState<any[]>([]);
  const [currentChatId, setCurrentChatId] = useState<number | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [chatLoading, setChatLoading] = useState(false);

  const [dietLogs, setDietLogs] = useState<any[]>([]);
  const [weightLogs, setWeightLogs] = useState<any[]>([]);

  const todayStr = new Date().toISOString().split("T")[0];

  // Load Initial Data
  useEffect(() => {
    fetchProfile();
    fetchChats();
    fetchDietLogs();
    fetchWeightLogs();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/profile");
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchChats = async () => {
    try {
      const res = await fetch("/api/chats");
      if (res.ok) {
        const data = await res.json();
        setChats(data);
        if (data.length > 0) {
          const firstId = data[0].id;
          setCurrentChatId(firstId);
          fetchMessages(firstId);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMessages = async (chatId: number) => {
    try {
      const res = await fetch(`/api/chats/${chatId}`);
      if (res.ok) {
        const data = await res.json();
        setMessages(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchDietLogs = async () => {
    try {
      const res = await fetch("/api/diet");
      if (res.ok) {
        const data = await res.json();
        setDietLogs(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchWeightLogs = async () => {
    try {
      const res = await fetch("/api/weight");
      if (res.ok) {
        const data = await res.json();
        setWeightLogs(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Chat Actions
  const handleSendMessage = async (userMsgText: string) => {
    if (!currentChatId) return;

    // Optimistic UI update
    const tempUserMsg = {
      id: Date.now(),
      chatId: currentChatId,
      role: "user",
      content: userMsgText,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);
    setChatLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chatId: currentChatId, message: userMsgText }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.reply) {
          setMessages((prev) => [...prev, data.reply]);
        }
      }
    } catch (e) {
      console.error("Error sending message:", e);
    } finally {
      setChatLoading(false);
    }
  };

  const handleNewChat = async () => {
    try {
      const res = await fetch("/api/chats", { method: "POST" });
      if (res.ok) {
        const newChat = await res.json();
        setChats((prev) => [newChat, ...prev]);
        setCurrentChatId(newChat.id);
        fetchMessages(newChat.id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteChat = async (id: number) => {
    try {
      await fetch(`/api/chats/${id}`, { method: "DELETE" });
      const updated = chats.filter((c) => c.id !== id);
      setChats(updated);
      if (updated.length > 0) {
        setCurrentChatId(updated[0].id);
        fetchMessages(updated[0].id);
      } else {
        handleNewChat();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Diet Log Actions
  const handleAddMeal = async (mealData: any) => {
    try {
      const res = await fetch("/api/diet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mealData),
      });
      if (res.ok) {
        fetchDietLogs();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteMeal = async (id: number) => {
    try {
      await fetch(`/api/diet?id=${id}`, { method: "DELETE" });
      fetchDietLogs();
    } catch (e) {
      console.error(e);
    }
  };

  // Weight Log Actions
  const handleAddWeightLog = async (data: any) => {
    try {
      const res = await fetch("/api/weight", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        fetchWeightLogs();
        fetchProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteWeightLog = async (id: number) => {
    try {
      await fetch(`/api/weight?id=${id}`, { method: "DELETE" });
      fetchWeightLogs();
    } catch (e) {
      console.error(e);
    }
  };

  // Update Profile
  const handleUpdateProfile = async (updatedData: any) => {
    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      });
      if (res.ok) {
        const saved = await res.json();
        setProfile(saved);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-800 dir-rtl" dir="rtl">
      {/* Sidebar */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} profile={profile} />

      {/* Main Container */}
      <main className="flex-1 flex flex-col h-full overflow-hidden bg-slate-50">
        
        {/* Top Header Navigation Bar */}
        <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0 shadow-2xs">
          <div className="flex items-center gap-3">
            <h2 className="font-bold text-slate-900 text-base flex items-center gap-2">
              {activeTab === "chat" && "💬 المحادثة مع المساعد الذكي"}
              {activeTab === "diet" && "🥗 نظام الأكل بالبخار"}
              {activeTab === "supplements" && "💊 مكملات التنشيف"}
              {activeTab === "fatloss" && "📉 رحلة التحول من السمنة"}
              {activeTab === "workout" && "🏋️‍♂️ تمارين و 10كم مشي"}
              {activeTab === "social" && "📱 صانع محتوى السوشيال"}
              {activeTab === "settings" && "⚙️ إعدادات وحاسبة السعرات"}
            </h2>
            <span className="hidden sm:inline-block text-xs bg-teal-100 text-teal-800 font-bold px-2.5 py-0.5 rounded-full">
              منصة المستشار
            </span>
          </div>

          {/* Quick Metrics Header Pills */}
          <div className="flex items-center gap-2 text-xs">
            <div className="hidden md:flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl text-slate-700 font-medium">
              <Droplets className="w-3.5 h-3.5 text-blue-500" />
              <span>هدف الماء: {profile.dailyWaterLiters || 3.5}L</span>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl text-slate-700 font-medium">
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span>السعرات: {profile.dailyCalorieGoal || 1700} kcal</span>
            </div>

            <div className="flex items-center gap-1 bg-teal-50 border border-teal-200 text-teal-800 px-3 py-1.5 rounded-xl font-bold">
              <span>الوزن: {profile.currentWeightKg || 90} كجم</span>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          
          {/* TAB 1: CHAT + SIDE CONTENT PANEL (Matches mockup exactly!) */}
          {activeTab === "chat" && (
            <div className="h-full flex flex-col lg:flex-row gap-6">
              {/* Chat Main Section */}
              <div className="flex-1 h-[calc(100vh-7rem)]">
                <ChatSection
                  currentChatId={currentChatId || 1}
                  messages={messages}
                  chats={chats}
                  onSendMessage={handleSendMessage}
                  onNewChat={handleNewChat}
                  onDeleteChat={handleDeleteChat}
                  loading={chatLoading}
                />
              </div>

              {/* Content Panel Side Dashboard (Matches design mockup card!) */}
              <div className="w-full lg:w-96 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4 overflow-y-auto shrink-0 max-h-[calc(100vh-7rem)]">
                <div className="border-b-2 border-teal-600 pb-2 flex justify-between items-center">
                  <h3 className="font-bold text-slate-900 text-base">📋 لوحة التغذية والمحتوى</h3>
                  <span className="text-[10px] bg-teal-50 text-teal-700 px-2 py-0.5 rounded-md font-bold">
                    إرشادات سريعة
                  </span>
                </div>

                {/* Info Card 1 */}
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-1">
                  <h4 className="font-bold text-teal-700 text-xs flex items-center gap-1.5">
                    <span>🥔</span> الأغذية البخارية الأساسية
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    البطاطس، السبانخ، الفاصوليا الخضراء (الماشطو)، وأسكالوب الدجاج. خالية تماماً من الدهون والمشروبات الغازية.
                  </p>
                </div>

                {/* Info Card 2 */}
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-1">
                  <h4 className="font-bold text-teal-700 text-xs flex items-center gap-1.5">
                    <span>💊</span> المكملات الموصى بها
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    الواي بروتين لحماية العضلات، الكافيين المائي لزيادة معدل الحرق، والأوميغا 3 للصحة العامة والمفاصل.
                  </p>
                </div>

                {/* Info Card 3 */}
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-1">
                  <h4 className="font-bold text-teal-700 text-xs flex items-center gap-1.5">
                    <span>🔥</span> نصيحة التنشيف وتجاوز الثبات
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    الالتزام بالعجز السعري والمشي 10 كيلومترات في أيام الراحة مع تمارين المقاومة 4 أيام أسبوعياً.
                  </p>
                </div>

                {/* Info Card 4: Soda Warning */}
                <div className="bg-rose-50 border border-rose-200 p-3.5 rounded-xl space-y-1 text-rose-900">
                  <h4 className="font-bold text-rose-700 text-xs flex items-center gap-1.5">
                    <span>🚫</span> حظر المشروبات الغازية
                  </h4>
                  <p className="text-xs text-rose-800 leading-relaxed">
                    قطع السسكريات والمشروبات الغازية يقلل مستويات الأنسولين ويرغم الجسم على استهلاك الشحوم المخزنة في الكرش.
                  </p>
                </div>

                {/* Quick Shortcuts */}
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <button
                    onClick={() => setActiveTab("diet")}
                    className="w-full py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                  >
                    🥗 فتح صانع الوجبات البخارية الكامل
                  </button>
                  <button
                    onClick={() => setActiveTab("supplements")}
                    className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                  >
                    💊 متابعة جدول المكملات اليومي
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: STEAM DIET */}
          {activeTab === "diet" && (
            <SteamDietSection
              logs={dietLogs}
              onAddMeal={handleAddMeal}
              onDeleteMeal={handleDeleteMeal}
            />
          )}

          {/* TAB 3: SUPPLEMENTS */}
          {activeTab === "supplements" && (
            <SupplementsSection dateStr={todayStr} />
          )}

          {/* TAB 4: FAT LOSS JOURNEY */}
          {activeTab === "fatloss" && (
            <FatLossJourneySection
              logs={weightLogs}
              profile={profile}
              onAddWeightLog={handleAddWeightLog}
              onDeleteWeightLog={handleDeleteWeightLog}
            />
          )}

          {/* TAB 5: WORKOUT & CARDIO */}
          {activeTab === "workout" && (
            <WorkoutCardioSection />
          )}

          {/* TAB 6: SOCIAL STUDIO */}
          {activeTab === "social" && (
            <SocialContentStudio />
          )}

          {/* TAB 7: SETTINGS */}
          {activeTab === "settings" && (
            <SettingsSection profile={profile} onUpdateProfile={handleUpdateProfile} />
          )}

        </div>
      </main>
    </div>
  );
}
